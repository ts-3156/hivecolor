package main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class CSVParser {

	ArrayList<ArrayList<String>> csv;

	public CSVParser(String fileName) throws IOException {
		csv = new ArrayList<ArrayList<String>>();

		File file = new File(fileName);
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
		String line = null;
		int lineNum = 0;
		String[] columns = null;

		while((line = br.readLine()) != null){
			lineNum++;
			if(line.length() <= 0)
				continue;

			columns = line.split(" ");
			if(columns.length <= 0)
				continue;

			readColumns(lineNum, columns);
		}
	}

	public void printCSV() {
		for(int i = 0; i < csv.size(); i++){
			ArrayList<String> line = csv.get(i);
			for(int j = 0; j < line.size(); j++){
				System.out.print(line.get(j));
				if(line.size() - 1 != j)
					System.out.print(" ");
			}
			System.out.println("");
		}
	}

	public void countFrequency(){
		HashMap<String, Integer> countMap = new HashMap<String, Integer>();

		for(int i = 0; i < csv.size(); i++){
			ArrayList<String> line = csv.get(i);
			for(int j = 0; j < line.size(); j++){
				String key = line.get(j);
				if(countMap.containsKey(key))
					countMap.put(key, countMap.get(key) + 1);
				else
					countMap.put(key, 1);
			}
		}

		getSortedList(countMap);
	}

	private ArrayList<Entry<String, Integer>> getSortedList(Map<String, Integer> map) {
		Map<String, Integer> copiedMap = new HashMap<String, Integer>(map);
		ArrayList<Entry<String, Integer>> sortedEntry = new ArrayList<Entry<String,Integer>>();

		while(!copiedMap.isEmpty()){
			Iterator<Entry<String, Integer>> iterator = copiedMap.entrySet().iterator();

			int max = -1;
			Entry<String, Integer> maxValueEntry = null;
			while(iterator.hasNext()) {
				Entry<String, Integer> entry = (Entry<String, Integer>) iterator.next();
				if(entry.getValue() <= max)
					continue;

				max = entry.getValue();
				maxValueEntry = entry;
			}

			assert maxValueEntry != null;

			sortedEntry.add(maxValueEntry);
			System.out.println(maxValueEntry.getKey() + " " + maxValueEntry.getValue());

			copiedMap.remove(maxValueEntry.getKey());
		}

		return sortedEntry;
	}

	private void readColumns(int lineNum, String[] columns) {
		ArrayList<String> lineArray = new ArrayList<String>();
		for(int i = 0; i < columns.length; i++)
			lineArray.add(columns[i]);

		csv.add(lineArray);
	}

	public static void main(String[] args) {

		try {
			CSVParser csvParser = new CSVParser("input.txt");
//			csvParser.printCSV();
			csvParser.countFrequency();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
	}
}
