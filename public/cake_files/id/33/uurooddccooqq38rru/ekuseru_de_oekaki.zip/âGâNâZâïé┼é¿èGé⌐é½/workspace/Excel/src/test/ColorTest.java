package test;

import java.awt.Color;

public class ColorTest {

	public ColorTest() {
		Color c = new Color(255, 0, 0);
		int rgb = c.getRGB();
		System.out.println("rgb=" + rgb);

		int b = rgb & 0x000000FF;
		int g = rgb >> 8 & 0x000000FF;
		int r = rgb >> 16 & 0x000000FF;
		System.out.println(b + ", " + g + ", " + r);

		int avgRGB = (r + g + b) / 3;
		System.out.println(avgRGB);

		int rrggbb = 0;

		int bb = avgRGB & 0x000000FF;
		System.out.println(bb);

		int gg = avgRGB << 8 & 0x0000FF00;
		System.out.println(gg);

		int rr = avgRGB << 16 & 0x00FF0000;
		System.out.println(rr);

		rrggbb = bb;
		rrggbb = rrggbb << 8 | bb;
		rrggbb = rrggbb << 8 | bb;
		System.out.println(rrggbb);

		rrggbb = bb | gg | rr;
		System.out.println(rrggbb);
	}

	public static void main(String[] args) {
		new ColorTest();
	}
}
