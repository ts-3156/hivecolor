package mixi4j.profle;

public interface Feed {

	public String getName();

}
