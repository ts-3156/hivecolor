package mixi4j.profle;

public interface Address {

	public String getRegion();

	public String getType();

	public String getLocality();
}
