package mixi4j.profle;

public interface Organization {

	public String getName();

}
