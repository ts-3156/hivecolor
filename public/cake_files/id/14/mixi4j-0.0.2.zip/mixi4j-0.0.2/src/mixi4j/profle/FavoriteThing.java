package mixi4j.profle;

public interface FavoriteThing {

	public int getOrder();

	public String getValue();

	public String getType();

}
